//Record、Partial 、 Required 、 Readonly、 Pick 、 Exclude 、 Extract 、 Omit
type User={
    id:number,
    name:string,
    age:number
}

let us:Record<string,User>={"0001":{id:10,name:"cjy",age:10}}
let us1:Partial<User>={id:10,age:20};//把User类型的属性变可选
let us2:Required<User>={id:1,name:'122',age:10};//把User类型的属性变为必须选
let us3:Readonly<User>={id:2,name:'1222',age:20};//把User类型的属性变为只读
//us3.name="cjy";错 name是只读的
type Pick1=Pick<User,"id"|"age">//返回新类型，是两种类型的交集
let us4:Pick1={id:1,age:20};
interface IA{}
interface IB extends IA{}
//Exclude排除 Extract精确
type Exclude1=Exclude<IA,IB>//返回新类型 判断A是不是B的子类是就返回never否则返回A
type Extract1=Extract<IA,IB>//返回新类型 判断A是不是B的子类是就返回A否则返回never