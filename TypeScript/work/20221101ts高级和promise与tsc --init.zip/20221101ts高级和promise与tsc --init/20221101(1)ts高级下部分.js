"use strict";
let us = { "0001": { id: 10, name: "cjy", age: 10 } };
let us1 = { id: 10, age: 20 }; //把User类型的属性变可选
let us2 = { id: 1, name: '122', age: 10 }; //把User类型的属性变为必须选
let us3 = { id: 2, name: '1222', age: 20 }; //把User类型的属性变为只读
let us4 = { id: 1, age: 20 };
