"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
//promise承诺  我承诺解决 拒绝
function promise1() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log('把大象放到冰箱里');
            resolve(); //解决方法
        }, 3000);
    });
}
//promise的调用方式 2种 1.async+await  2.then
function callAsync() {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('打开冰箱');
        yield promise1();
        console.log("关闭冰箱");
    });
}
callAsync();
function callAsync1() {
    promise1().then(res => {
        console.log("成功了");
    }).catch(err => {
        console.log("失败了");
    });
}
callAsync1();
//promise承诺函数传字符
function promise2() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            //resolve("hellowold");
            reject('拒绝了');
        }, 1000);
    });
}
function callAsync2() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let ret = yield promise2();
            console.log(ret);
        }
        catch ( //catch中执行拒绝的方法
        _a) { //catch中执行拒绝的方法
            console.log("你被拒绝了");
        }
    });
}
//promise传字符串数组
function promise3() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(['hello', 'world']);
        }, 1000);
    });
}
function callAsync3() {
    return __awaiter(this, void 0, void 0, function* () {
        let rets = yield promise3();
        console.log(rets);
    });
}
