"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// 作业
// 1.TS工具类型分别有什么作用
//     Record、Partial 、 Required 、 Readonly、 Pick 、 Exclude 、 Extract 
console.log('Record 与 索引签名很像，都是用于定义未知数量的 keyType: valueType 形式，', 'Partial 把类型所有属性变成可选', 'Required 把类型的所有属性变成必须输入', 'Readonly 把类型啥的所有属性全部变成只读', 'Pick 从类型定义的属性中，选取指定一组属性(取出子集)，返回一个新的类型定义。 ', 'Omit 与Pick作用相似，只不过是：以一个类型为基础支持剔除某些属性，然后返回一个新类型', 'Exclude 排除 返回新类型 判断A是不是B的子类，是就返回never 否则返回A', 'Extract 精确 返回新类型 判断A是不是B的子类，是就返回A 否则返回never');
// Record
let RecordType = {
    '001': { id: '1', name: "某" },
    '002': { id: '2' },
    '003': { id: '3', name: '某某' }
};
//Partial
let PartialType = { id: '4' };
let PartialType2 = { id: '5', name: '程' };
//Required
let RequiredType = { id: '6', name: 'xx' };
//Readonly
let ReadonlyType = { id: '7', name: 'xxx' };
var Sex20221101;
(function (Sex20221101) {
    Sex20221101[Sex20221101["MAN"] = 0] = "MAN";
    Sex20221101[Sex20221101["GIRL"] = 1] = "GIRL";
})(Sex20221101 || (Sex20221101 = {}));
// 3.函数getUserList返回承诺Promise<void>  3秒后解决resolve
function getUserList() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve();
        }, 3000);
    });
}
// 4函数fetchApi返回承诺Promise<string> 1秒后拒绝 传出拒绝原因
function fetchApi() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            reject('没什么原因，嫌弃你，妨碍我玩原神');
        }, 1000);
    });
}
// 5.用两种方法调用getUserList
function callAsync11() {
    return __awaiter(this, void 0, void 0, function* () {
        yield getUserList();
    });
}
function call2() {
    getUserList().then(res => { }).catch(err => { });
}
// 6.用两种方法调用fetchApi
function callAsync13() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield fetchApi();
        }
        catch (_a) {
            console.log("你被拒绝了");
        }
    });
}
function call4() {
    fetchApi().then(res => { }).catch(err => { console.log("你被拒绝了"); });
}
// 7.ts --init生成tsconfig.json  tsc直接编译当前目录下的所有文件
//      "target": "es2015", 生成目标js文件的版本2015
//      “lib":["dom"],  用到哪些库文件  如console.log要用dom库
//      "module": "commonjs" 模块化用commonjs类型
//      "strict": true,严格类型 
//      "noImplicitAny": false, 不实现Any
