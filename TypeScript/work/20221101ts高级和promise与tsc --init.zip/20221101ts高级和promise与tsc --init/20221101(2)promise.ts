//promise承诺  我承诺解决 拒绝
function promise1():Promise<void>{
    return new Promise((resolve:()=>void,reject:()=>void)=>{
        setTimeout(() => {
            console.log('把大象放到冰箱里');
            resolve();//解决方法
        }, 3000);
    })
 }
 //promise的调用方式 2种 1.async+await  2.then
 async function callAsync(){
     console.log('打开冰箱')
     await promise1();
     console.log("关闭冰箱")
 }
 callAsync();
 function callAsync1(){
     promise1().then(res=>{
         console.log("成功了")
     }).catch(err=>{
        console.log("失败了")
     })
 }
 callAsync1();
 //promise承诺函数传字符
 function promise2():Promise<string>{
     return new Promise((resolve:(arg:string)=>void,reject:(arg:string)=>void)=>{
          setTimeout(()=>{
             //resolve("hellowold");
             reject('拒绝了')
          },1000)
     })
 }
 async function callAsync2(){
    try{
     let ret:string= await promise2();
     console.log(ret);
    }catch{//catch中执行拒绝的方法
        console.log("你被拒绝了")
    }
    
 }
//promise传字符串数组
function promise3():Promise<string[]>{
     return new Promise(
     (resolve:(arg1:string[])=>void,reject:(arg1:string[])=>void)=>{
         setTimeout(() => {
            resolve(['hello','world'])
         }, 1000);
     }
     )
}
async function callAsync3(){
    let rets:string[]= await promise3();
    console.log(rets);
}