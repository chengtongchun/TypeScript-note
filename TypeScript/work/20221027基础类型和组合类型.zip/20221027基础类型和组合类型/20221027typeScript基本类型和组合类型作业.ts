// 1.typescript是什么？为什么要学ts
console.log(
  "TypeScript是JavaScript的一个超集，也支持es6。",
  '\n为什么学？：\n(1)ts比js多了许多语法、保证结果安全的类型检查;(2)具有静态类型的JavaScript;(3)避免经典的错误"undefined is not a function";(4)重构代码更容易。(5)源码更易阅读'
);

// 2.编程完成下面任务
//    x1,x2,x3定义为数字类型 s1,s2,s3定义为字符串类型
var x1: number, x2: number, x3: number;

var s1: String, s2: String, s3: String;

//    let s4="456" 把s4转为number类型赋给x3
let s4 = "456";
x3 = <number>(<any>s4);
console.log(x3, typeof x3);
console.log('\n')
//    定义a1为any a2为unknown a3为never
//    a1=10;a1="12";a2=true;a3=undefined  这一行那个语句有错
var a1: any, a2: unknown, a3: never;
console.log(
  'a1=10;a1="12";a2=true;a3=undefined中',
  "a3=undefined错，a3类型是永不存在值得类型，不能有=号"
);
console.log('\n')

a1 = 1999;
a1 = "1019";
a1 = true;
a2 = 1999;
a2 = "1019";
a2 = true;
//  3.解释下面类型的意思
//    any unknown never void undefined null
console.log(
  " any是任何类型的父类型，同时也是任意类型的子类型(any失去了typescript给我们的类型安全性)\n",
  "unknown是任何类型的父类型，仅此而已(没有失去安全性,可以限制某些变量的行文，使我们的编码习惯更加严谨)\n",
  "never 永不存在值的类型 如将引发异常的函数\n",
  "void 函数没有返回值 null对象值缺失 undefined未定义的值\n"
);
console.log('\n')

//  4.定义元素类型
//     age为字符串数字的元组
//     id的类型可能是number,string,undefined
    var age:[String,number];
    age=['age',23];

    var id:number|string|undefined;
    id=1999;id='10',id=undefined;//id=null;//报错
    console.log('\n')

//   5.定义枚举
//      DIR方向{UP,LEFT,DOWN,RIGTH}让变量move为DIR类型中的UP
//      COLOR{RED='#f00',GREEN='#0f0',BLUE='#00f'}
    enum DIR{UP,LEFT,DOWN,RIGTH='右边'}
    let move:DIR=DIR.UP;
    //let move2:DIR='LEFT';//报错
    let move3:DIR=DIR.LEFT;
    let move4:DIR=DIR.RIGTH;

    enum COLOR{RED='#F00',GREEN='#0F0',BLUE='#00F'}
    let colors:COLOR=COLOR.GREEN

    console.log(move,move3,move4,colors)//0 1 右边 #0F0

//   6.自定义类型
//      性别Sex为男女   学历Degtree为本科大专高中
    type Sex='男'|'女';
    type Degtree='本科'|'大专'|'高中'

    var sex:Sex//='男';
    sex='女';sex='男';//sex='无性';//报错

    var deg:Degtree;
    deg='高中';//deg='初中';//报错
