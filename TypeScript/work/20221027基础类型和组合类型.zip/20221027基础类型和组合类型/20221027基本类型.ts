//基本类型

var x1:number=10,x2:number=12.33,x3:number=0x232,x4:number=0b01;
let s1:string="1233",s2:string='sfsdfds',s3:string=`fsdfdsf`;
const b1:boolean=true,b2:boolean=false;
//类型推断
var y1=10,y2="123",y3=true;
y1=122;
y2='1232';
y2=`${y1}`;
y3=y1>100;
y1=<number><any>y2;//强制类型转换  先转为any--》number
//特殊类型
var a1:any;//any随便什么类型
a1=10;a1="122";a1=true;

let an1:unknown;//unknown确保用此类型的人声明类型 
an1=1212;
an1="sdfsdfsd";
let nv1:never;//never永不存在值的类型 不要有=
//void 函数没有返回值  null对象值缺失 undefined未定义的值