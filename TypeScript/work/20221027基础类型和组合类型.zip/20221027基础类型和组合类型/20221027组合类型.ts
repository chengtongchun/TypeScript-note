//组合类型
//元组
let x:[number,string];
x=[10,"12"]
console.log(x)
let age:[string,number]=["age",30]
let deg:[number,string]=[1,"A"]
//联合类型
let y:number|string; //只能是数字或字符串类型
y=12; y="12";  //y=true;
let yy1:number|string|undefined;//yy1只能是数字 字符串 undefined
//枚举
enum Deg{A=1,B,C}
enum Color{Red,Green,Blue}
let deg1:Deg=Deg.A;
let c1:Color=Color.Green;
//自定义类型
type MyDeg='A'|'B'|'C';
let mydeg:MyDeg='A'; 