//泛型：广泛的类型 用的时候<?>指定类型 T是Type的第一个字母
function f1<T>(arg:T){
    console.log(typeof(arg));
}
f1('1212')
f1<string>("1212");
f1<number>(123);
type City="bj"|"tj"
//f1<City>('sz');自定义类型作为模板类型
//有多个类型
function f2<A,B>(arg1:A,arg2:B):A{
    console.log(arg1);
    return arg1;
}
let ff2:string=f2<string,number>("cjy",123)
//类里面用泛型 放在类名后
class MyNumber<T> {
    constructor(z:T){
        this.zero=z;
    }
     zero: T; 
     add(x: T, y: T){

     };
     }
var mynum1=new MyNumber<string>("1");
mynum1.zero="0";
console.log(mynum1.add("1","2"));
//接口中用泛型T=any 给一个默认类型 放在接口后
interface IResult<T=any>{
    code:number,
    message:'成功'|'失败';
    result:T
}
type User={
    name:string,
    age:number
}
function f3(res:IResult<User>){
    console.log(typeof(res.result))   
}