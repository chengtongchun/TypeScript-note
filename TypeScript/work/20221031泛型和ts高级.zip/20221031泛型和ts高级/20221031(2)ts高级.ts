//有序 但不重复
var set1=new Set<string>();
set1.add("1221");
set1.add("1221");
set1.add("1221");
set1.add("1221");
set1.add("1221");
set1.forEach(i=>{
    console.log(i);
})
//map 键key值value对  key不能重复
var map1=new Map<string,number>;
map1.set('name',1212);
map1.set('age',20);
map1.set('name',11111);
console.log(map1.get('name'));
//keyof就是
type Stu={
    id:string,
    name:string
}

let students:Stu[]=[{id:"1",name:"cjy"},{id:"2",name:"cjy2"}]
//TS工具类型Record、Partial 、 Required 、 Readonly
type EmployeeType={
     id:number,
     fullname?:string,
     role:"Designer"|"Developer"
}
let employees: Record<string, EmployeeType> = {
    "001": { id: 1, fullname: "John Doe", role: "Designer" },
    "002": { id: 2, fullname: "Ibrahima Fall", role: "Developer" },
    "003": { id: 3, fullname: "Sara Duckson", role: "Developer" },
}
//Partial类的作用就是把类型所有属性变成可选
let emp1:EmployeeType={id:4,fullname:'cjy',role:'Designer'}
let emp2:Partial<EmployeeType>={id:4,fullname:'cjy'}
//Required就是把类型的所有属性变成必须输入
let emp3:Required<EmployeeType>={id:5,fullname:'abc',role:'Developer'}
emp3.fullname="aaaaaa";
//Readonly就是把类型的所有属性全部变成只读
let emp4:Readonly<EmployeeType>={id:5,fullname:'abc',role:'Developer'}
//emp4.fullname="------"