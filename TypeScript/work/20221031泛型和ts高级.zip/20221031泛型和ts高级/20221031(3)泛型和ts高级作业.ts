// 作业
//  1.定义结果类<T=any>  属性有code message只有成功失败 result:T}
enum MESSAGE {
  "成功",
  "失败",
}
class Result<T> {
  code:number
  message:MESSAGE;
  result:T;
  constructor(code:number,message:MESSAGE,result:T){
    this.code=code;this.message=message;this.result=result;
  }
}

//  2.写泛型函数add<A,B>(a:A,b:B):A
function add<A, B>(a: A, b: B): A {
  return a;
}
//  3.写接口IUsb{name； insert方法}
interface IUSB {
  name: string;
  insert(): void;
}
//   计算机类Compute<T扩展IUsb>{ 方法:useUsb(usb:T)}
class Compute<T extends IUSB> {
  useUsb(usb: T) {
    usb.insert();
  }
}
class Mp3 implements IUSB {
  name: string = "mp3";
  insert() {
    console.log("mp3");
  }
}
var shenzhou = new Compute<IUSB>();
shenzhou.useUsb(new Mp3());

//  4.写一个连接字符或数字的类MyConcat<T extends Array<string>|Array<number>>
class MyConcat<T extends Array<string> | Array<number>> {
  concat(items: T) {
    let s: string = "";
    for (let i in items) {
      s += items[i].toString();
    }
  }
}
//  5.map和set有什么特点
console.log("map 键值对 key不能重复", "set 有序 不重复");
    new Map<string,number>();
var myMap=new Map<string,number>();
myMap.set('ctc',1999);
myMap.set('ctc',1019);
myMap.set('ying',1000000);
console.log(myMap.get('ctc'))

//     new Set<string>();
var mySet=new Set<string>();
mySet.add('c');
mySet.add('tc');
mySet.add('19991019');
mySet.add('c');
mySet.forEach(s=>{
    console.log(s)
})
//  6.解释
//     type定义类型 Weak名称<T> = { [K in keyof T]?: T[K]; }
console.log(
  "[K in keyof T]的意思是循环取出key如id,name放前面",
  " ?: T[K]就是后面的值"
);
//     使用 type Stu={id:number,name:string}   let st:Weak<Stu>={}把类型Stu全部变成可选
type Stu31 = { id: number; name: string };
let st: Partial<Stu31> = { id: 1999 };
console.log(st);
//   7. 解释Record、Partial 、 Required 、 Readonly的用法
console.log(
  "Record 与 索引签名很像，都是用于定义未知数量的 keyType: valueType 形式，",
  "Partial 把类型所有属性变成可选",
  "Required 把类型的所有属性变成必须输入",
  "Readonly 把类型啥的所有属性全部变成只读"
);
