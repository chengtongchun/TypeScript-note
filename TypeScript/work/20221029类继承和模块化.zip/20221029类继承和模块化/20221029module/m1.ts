export abstract class Base{

}
export function add(a:number,b:number):number{
    return a+b;
}
//
export enum XUELI{A,B,C,D}
export type Stu={
    id:number
}
export interface IUsb{

}
export default class B{
    run():void{
        console.log('b...run')
    }
}