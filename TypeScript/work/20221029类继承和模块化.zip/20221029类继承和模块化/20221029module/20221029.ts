// 2.建module文件夹，下面写m.ts分别输出
// 抽象类Base{id为数字或字符 name为字符 构造函数 abstract say():void;}  ERRORCODE错误代码枚举{不能启动404,电压不够401,角度过高500,没有权限603}
// 地址类型Address{深圳广州东莞}      接口IMachine{volt电压 方法run stop}    IHuman接口{angle角度 方法：up举起来 turn转动} 
// 常量TITLE='机器人系统'  导出方法useMachine(mach:IMachine){mach.run}
// 默认导出方法print(printObj:string[]|string|(()=>string)){console.log(printObj);}
export abstract class Base{
    id:string | number ;
    name:string ;
    constructor(id:string|number,name:string){
        this.id=id;
        this.name=name;
    }
    abstract say():void;
}

export enum ERRORCODE{CanNotStart=404,TheVoltageIsNotEnough=401,AngleIsTooHigh=500,HaveNoLegalPower=603}

export type Address='深圳'|'广州'|'东莞'

export interface Imachine{
    voit:string;
    run():void;
    stop():void;
}
export interface IHuman{
    angle:string;
    up():void;
    turn():void;
}

export const TITLE='机器人系统'

export function useMachine(mach:Imachine){
     mach.run()
}
export default function print(printObj:string[]|string|(()=>string)){
    console.log(printObj);
}
