"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.XUELI = exports.add = exports.Base = void 0;
class Base {
}
exports.Base = Base;
function add(a, b) {
    return a + b;
}
exports.add = add;
//
var XUELI;
(function (XUELI) {
    XUELI[XUELI["A"] = 0] = "A";
    XUELI[XUELI["B"] = 1] = "B";
    XUELI[XUELI["C"] = 2] = "C";
    XUELI[XUELI["D"] = 3] = "D";
})(XUELI = exports.XUELI || (exports.XUELI = {}));
class B {
    run() {
        console.log('b...run');
    }
}
exports.default = B;
