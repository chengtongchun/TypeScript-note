// 作业
//   1. typescript中 类能不能继承多个类 ？类能不能实现多个接口？接口能不能继承多个接口？
//    接口能不能继承多个类？抽象类能不能实例化？
console.log(
  "类不能继承多个类，可以实现多个接口，接口可以继承多个接口，接口可以继承多个类。抽象类不能实例化，需要子类继承在实例化子类"
);
//    2.建module文件夹，下面写m.ts分别输出
//    抽象类Base{id为数字或字符 name为字符 构造函数 abstract say():void;}  ERRORCODE错误代码枚举{不能启动404,电压不够401,角度过高500,没有权限603}
//    地址类型Address{深圳广州东莞}      接口IMachine{volt电压 方法run stop}    IHuman接口{angle角度 方法：up举起来 turn转动}
//    常量TITLE='机器人系统'  导出方法useMachine(mach:IMachine){mach.run}
//    默认导出方法print(printObj:string[]|string|(()=>string)){console.log(printObj);}
import { Base, Imachine, IHuman, useMachine } from "./20221029module/20221029";
import print from "./20221029module/20221029";
import type { Address } from "./20221029module/20221029";
//    3.建machine.ts导入 m.ts中的
//     类Robot{address:Address}继承Base实现IMachine和IHuman
class Robot extends Base implements IHuman, Imachine {
  address: Address; //地址
  angle: string; //角度
  voit: string; //电压
  constructor(
    id: string | number,
    name: string,
    address: Address,
    angle: string,
    voit: string
  ) {
    super(id, name);
    this.address = address;
    this.angle = angle;
    this.voit = voit;
  }
  say() {
    console.log("到了");
  }
  up() {
    console.log("举起");
  }
  turn() {
    console.log("转动");
  }
  run(): void {
    console.log(this.id + this.name);
  }
  stop(): void {}
}
//     构造机器人数组Robots[]实例化3个机器人
let Robots: Robot[] = [
  new Robot("ctc", "程某", "深圳", "45度", "120v"),
  new Robot("ct", "某某", "东莞", "45度", "120v"),
  new Robot("c", "某", "广州", "45度", "120v"),
];
console.log(Robots);
//     forEach调用useMachine
Robots.forEach((e) => {
  useMachine(e);
});
//     解释print(printObj:string[]|string|(()=>string)){console.log(printObj);}并调用它
console.log(
  "printObj是print参数，printObj可以是字符串数组，也可以是字符串，还可以是个函数方法"
);
print("你是谁");
print(["1999", "10", "19"]);
print(function () {
  return "这题不会写";
});
