//接口套接口
enum DEG {A=1,B,C}
interface IAddress{
    city:string
    phone:number
}
interface IUser{
    id:number|string|undefined
    name:string
    age?:number
    deg:DEG
    address:IAddress[]
}
class User implements IUser{
    id:'111'
    name:'cjy'
    deg:DEG.A
    address: [
        {city:'bj',phone:200008}
    ]
}