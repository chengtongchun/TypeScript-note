//函数
/**
 * 定义增加函数 
 * @param x 
 * @param y 
 * @returns 
 */
function add(x:number,y:number=1):number{
    return x+y;
}
let c:number=add(1,2)
console.log(add(7))//y默认是1
//箭头函数
let add1=(x:number,y:number):number=>{
    return x+y;
}
//参数是联合类型string[] | number[]  
//...args是省略号  
function fn1(...args:string[]|number[]){
    for(let i in args){
        console.log(args[i])
    }
}
fn1("我是字符串数组");
fn1(1,2,3,4,5,6);
//fn1(true,false,true,false)是错的
//函数重载 名称相同 类型不同
/*
    function addfn(a:number,b:number):number{
        return a+b;
    }
    function addfn(a:string,b:number):string{
        return a+b;
    }
    function addfn(a:boolean,b:boolean):boolean{
        return a+b;
    }
*/