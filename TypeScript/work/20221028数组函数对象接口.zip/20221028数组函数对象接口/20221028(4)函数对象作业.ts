// 作业
//   1.定义数组1,7,9,2,3,4并遍历该数组
let array:number[]=[1,7,9,2,3,4];
array.forEach(a=>{
  console.log(a);
})
//   2.定义学生类型Student 存放学生的基本情况
//     id字符或数字 name字符 age可选数字 score成绩数字  学历degree可选枚举{本科专科高中} 性别sex可选{男女}
enum DEG{本科,专科,高中}

type Student={
  id:number|string,
  name:string,
  age?:number,//?号是可选可不选
  sex?:'男'|'女',
  score:number,
  deg:DEG
}
//   3.定义学生类型的数组
let sts:Student[]=[];
sts[0]={id:12,name:'cc',score:123,deg:DEG.专科};
console.log(sts[0])//{ id: 12, name: 'cc', score: 123, deg: 1 }
sts[1]={id:'1999',name:'ctc',score:124,deg:DEG.专科,sex:'男'}
console.log(sts[1])

//   4.定义4个函数
//       增加function addStudent(st:Student)
//      修改modiStudent(st:Student)
//       删除delStudent(id:number)
//       caclScore()统计成绩
function addStudent(stu:Student){//添加函数
  sts.push(stu);
}
addStudent({id:'2004',name:'zjh',score:124,deg:DEG.本科,sex:'女'})

function modiStudent(id:string|number){//修改函数
  var index:number=0;
  for(let i in sts){
    if(sts[i].id==id){
      index=<number><unknown>i;
      break;
    }
  }
  // var index=sts.findIndex(s=>s.id==id)
  sts[index].id=(Math.random()*10000)
}
modiStudent('1999')

function delStudent(id:number|string){//删除函数
  var index:number=0;
  for(let i in sts){
    if(sts[i].id==id){
      index=<number><unknown>i;
      break;
    }
  }
  sts.splice(index,1)
}
delStudent(12)
console.log(sts)

/**
 * 
 * @param obj 
 * @returns 
 */
function caclScore(obj){//统计函数
  let stufun=obj;
  console.log(stufun)
  return stufun.reduce((max,st)=>max+=st.score,0)
}
console.log(caclScore(sts))

//   5.写类Student类
//      属性为 id字符或数字 name字符  score成绩  性别sex可选{男女}
//      方法为add modi del不实现
class StudentClass{
  id:string|number;
  name:string;
  score:number;
  sex:'男'|'女';
  add():void{
    
  }
  modi():void{

  }
  del():void{

  }
}