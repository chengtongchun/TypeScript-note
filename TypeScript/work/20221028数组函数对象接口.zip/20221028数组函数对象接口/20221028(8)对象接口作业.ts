// 作业
//   1.写Animal类
//       属性id name字符 color枚举 weight体重
//      构造函数 id name color weight
//       方法run(卡路里)会消耗体重 eat()会增加体重
//   2.保护Anmial类的属性
//     id为私有 name为类所有 color为只读 weight为保护
enum COLOR {
  RED=1,
  BLUE=10,
  GREEN=20,
  PINK=30,
}
class Animal {
  private id: string | number;
  public name: String;
  readonly color: COLOR;
  protected weight: number;
  constructor(id: string|number, name: string, color: COLOR, weight: number) {
    this.id = id;
    this.name = name;
    this.color = color;
    this.weight = weight;
  }
  run(kll: number): void {
    this.weight = this.weight - kll;
  }
  eat(food: number): void {
    this.weight = this.weight + food;
  }
}
//   3.写Dog继承Animal类
//     增加属性 气味small
//     增加方法call 气味值大于20就叫
//     改写eat方法根据气味值决定吃不吃
class Dog extends Animal {
  small: number;
  constructor(id:number,name:string,color:COLOR,weight:number,small:number){
    super(id,name,color,weight);//super调用父类的构造函数 super()
    this.small=small;
  }
  call(s: number): string {
    this.small = s;
    if (s > 20) return "啊啊啊啊啊，气味太大了";
    return "气味还能接受";
  }
  eat(food: number): void {
    if (this.small < 20) {
      this.weight = this.weight + food;
    }
  }
}
var dog1=new Dog(1,'dog1',COLOR.BLUE,100,10)
//    4.写接口Flyable
//      fly方法
interface Flyable {
  fly(): void;
}
//    5.类BIrd继承Animal实现Flyable
class BIrd extends Animal implements Flyable {
  fly(): void {
    console.log("飞了");
  }
}
//    6.写学生接口类
//        id name age  deg等级枚举  address地址 remark简历
//      地址：城市 邮编 街道
//      简历：日期 工作经历 职务
enum DEG{S,A,B,C,D,E}
type Address={
  city:string,
  mailbox:string,
  street:string
}
type Resume={
  date:string,
  job:string,
  post:string
}
interface Student{
  id:string|number;
  name:string;
  deg:DEG;
  address:Address;
  remark:Resume;
}

