//类的定义
class Person{
    id:number|string;//类的成员属性
    name:string
    constructor(id:number,name:string){//类的构造方法
        this.id=id;
        this.name= name;
    }
    say():void{//类的成员方法
        console.log(this.name)
    }
   getName():string{
        return this.name;
    }
}
var p=new Person(1,"cjy");
console.log(p);
p.say();
//类的修饰
class Student{
    private id:number|string;//类私有
    private name:string;
    private score?:number;
    constructor(id:number,name:string){
        this.id=id;
        this.name=name;
    }
}