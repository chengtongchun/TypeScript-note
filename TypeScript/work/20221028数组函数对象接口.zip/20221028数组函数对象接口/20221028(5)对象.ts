//类的定义
class Person{
    id:number|string;//类的成员属性 默认是public
    name:string;
    constructor(id:number,name:string){//类的构造方法 没有返回类型
        this.id=id;
        this.name= name;
    }
    say():void{//类的成员方法 public 没有返回值的要void
        console.log(this.name)
    }
   getName():string{
        return this.name;
    }
}
var p=new Person(1,"cjy");
p.id='abcdefg';
console.log(p);
p.say();
//类的修饰public protected private static readonly 
//public protected private static可以放在那里 修饰属性 方法 
//它们分别什么意思 public谁都可以访问 private只要自己能访问 protected只有子类能访问
//static类方法属性
//readonly 只有构造函数能赋值属性
 class Student{
    public id:number|string;
    private name:string;
    protected score?:number;
    static age:number;
    readonly deg:number;
    public constructor(id:number,name:string,deg:number){
        this.id=id;
        this.name=name;
        this.deg=deg;
    }
    public say(){
      //this.deg=12;
      console.log(this.name);
    }
    public static ssay(){
       console.log(this.name);
    }
}
class WomonStudent extends Student{
    public say(): void {
        console.log(this.score);
    }
}
var st1=new Student(11,"cjy",12);
Student.age;
Student.ssay();
