interface IUsb{//usb接口 规定了前后端交互的规范
    id:string;
    name:string;
    insert():void;
    off():void;
}
//接口的实现
class Up implements IUsb{
    id:'up00001'
    name:'up'
    insert(): void {
        console.log('up insert')
    }
   off(): void {
       console.log(this.name+"...off")
   }
}
class Mp4 implements IUsb{
    id:'mp00001'
    name:'Mp4'
    insert(): void {
        console.log('mp4 insert')
    }
   off(): void {
       console.log(this.name+"...off")
   }
} 
//接口作为参数
function useUsb(u:IUsb):void{
     u.insert();
     console.log('.......');
     u.off();
}
//接口作为返回值
function retUsb():IUsb{
    return new Mp4;
}
useUsb(new Mp4);
useUsb(new Up);