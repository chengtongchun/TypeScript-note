let ar1:number[]=[1,3,4,5];
ar1[0]=2;
ar1.forEach(e=>{
     console.log(e);
})
enum DEG {A=1,B,C}
type Stu={
    id:number|string,
    name:string,
    score?:number,//？可选择
    age?:number,
    deg:DEG
}
let sts:Stu[]=[];
sts[0]={id:12,name:"cjy1",deg:DEG.A}
sts[1]={id:13,name:"cjy2",score:100,deg:DEG.B}
sts[2]={id:14,name:"cjy3",deg:DEG.C}
sts[3]={id:15,name:"cjy4",deg:DEG.C}
sts.forEach(s=>{
    console.log(s.id,s.name,s.deg)
})
//元组数组
let yz1:[number,string][]=[[1,"222"],[2,"cjy"]]
//二维数组
var marr:number[][] = [[1,2,3],[23,24,25]] 
marr[0][1]=12;